#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>

#include "esp_log.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/timers.h"
#include "freertos/event_groups.h"
#include "freertos/queue.h"

#include "gpio.h"
#include "adc.h"
#include "wifi.h"
#include "udp_s.h"
#include "nvs_esp.h"
#include "ap.c"
#include "host_name.h"
#include "tcp_s.h"
#include "pwm.h"

#define STR_LEN 128

//#define UDP_COM
#define TCP_COM

const char *TAG_MAIN = "MAIN";

TaskHandle_t udp_server_handle = NULL;
TaskHandle_t tcp_server_handle = NULL;

//unused
//#define SSID "Totalplay-2.4G-b518"
//#define PASS "Qxm2EAzh99Ce7Lfk"

void activate_access_point()
{
    init_ap();
    vTaskDelay(pdMS_TO_TICKS(1000));
}

void app_main(void)
{
    esp_err_t error;

    init_gpio();
    adc_init();
    ledc_init();

    //nvs
    char ssid[STR_LEN] = "\0", pass[STR_LEN] = "\0", dev_name[STR_LEN] = "esp_default_name";
    ESP_ERROR_CHECK(init_nvs());

    //char str[STR_LEN] = "\0";
    //read_nvs(key_ssid, str, sizeof(str));

    //get device name
    read_nvs((char *)key_dev_name, dev_name, sizeof(dev_name));

    //get ssid
    error = read_nvs((char *)key_ssid, ssid, sizeof(ssid));
    if(error == ESP_ERR_NVS_NOT_FOUND || strcmp(ssid, "RESET") == 0)
        activate_access_point();
    else
    { ;

        //get password
        read_nvs((char *)key_pass, pass, sizeof(pass));

        //wifi station
        wifi_connection(ssid, pass, dev_name);
        
        ESP_LOGE(TAG_MAIN, "WIFI waiting....");
        vTaskDelay(pdMS_TO_TICKS(15000));
        if(!connected_w)
            activate_access_point();
    }
    
#ifdef UDP_COM
    xTaskCreate(udp_server_task, "udp_server_task", 4096, (void *)AF_INET, 5, &udp_server_handle);
#endif
#ifdef TCP_COM
    xTaskCreate(tcp_server_task, "tcp_server_task", 4096, (void *)AF_INET, 5, &tcp_server_handle);
#endif

    //set led and read adc
    while(1)
    {
        vTaskDelay(pdMS_TO_TICKS(50));
        set_led(l_state);
        read_adc_input(CHANNEL_0);
        get_button();

        //TODO: wifi led

        //if sudden disconect and no ap active
        if(!connected_w && !active_ap) 
            activate_access_point();
    }
}

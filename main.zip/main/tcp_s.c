#include "tcp_s.h"

int sock;

TimerHandle_t timer1;
const int timerId = 1;

static const char *TAG_T = "TCP";

uint8_t send_f = 0;
int counter;

char rx_buffer[STR_LEN], rx_buffer_xor[STR_LEN], tx_buffer[STR_LEN], tx_buffer_cifrado[STR_LEN], *ptr, command[COMMANDS_QUANTITY][STR_LEN], pasword_iot[50], pasword_iot_desif[50];


void vTimerCallback(TimerHandle_t pxTimer)
{
	ESP_LOGI(TAG_T, "Timer called");
	
    sprintf(tx_buffer, KEEP_ALIVE);
    aplicarXor(tx_buffer, tx_buffer_cifrado); 
    send(sock, tx_buffer_cifrado, strlen(tx_buffer_cifrado), 0);
    ESP_LOGI(TAG_T, "Message send to %s: %s", HOST_TCP, tx_buffer);
}

void setTimer()
{
	ESP_LOGI(TAG_T, "Timer initialized");
	timer1 = xTimerCreate("timer",
                        (pdMS_TO_TICKS(TIMER_RESET)),
                        pdTRUE,
                        (void *)timerId,
                        vTimerCallback);

	if(timer1 == NULL)
		ESP_LOGE(TAG_T, "Timer not created");
	else
	{
		if( xTimerStart(timer1, 0) != pdPASS)
			ESP_LOGI(TAG_T, "Timer could not be set to Active state");
	}
}

void tcp_server_task(void *pvParameters)
{
    struct sockaddr_in dest_addr;
    int counter_cmmd, counter_word;
    dest_addr.sin_addr.s_addr = inet_addr(HOST_TCP);
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(PORT_TCP);

    while(1)
    {
        sock = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
        if (sock < 0) {
            ESP_LOGE(TAG_T, "Unable to create socket: errno %d", errno);
            break;
        }
        ESP_LOGI(TAG_T, "Socket created, connecting to %s:%d", HOST_TCP, PORT_TCP);

        // Set timeout
        struct timeval timeout;
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;
        setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof timeout);

        int err = connect(sock, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
        if (err != 0) {
            ESP_LOGE(TAG_T, "Socket unable to connect: errno %d", errno);
            break;
        }
        ESP_LOGI(TAG_T, "Successfully connected to: %s", HOST_TCP);

        //Login 
        sprintf(tx_buffer, LOGIN_KEY);
        send(sock, tx_buffer, strlen(tx_buffer), 0);  
        ESP_LOGI(TAG_T, "Message send to %s: %s", HOST_TCP, tx_buffer);
        int len = recv(sock, rx_buffer, sizeof(rx_buffer) - 1, 0);
        if(len < 0) 
        {
            ESP_LOGE(TAG_T, "Error occurred during receiving: errno %d", errno);
            break;
        }

        rx_buffer[len] = '\0'; // terminator
        ESP_LOGI(TAG_T, "Received %d bytes", len);
        ESP_LOGI(TAG_T, "%s", rx_buffer);

        if(strncmp(rx_buffer, "ACK", 3) != 0) 
        {
            ESP_LOGE(TAG_T, "Login failed");
            break;
        }
        //login success

        //get pass
        ptr = &rx_buffer[4];
        counter = 0;
        while(*ptr != '\0' || *ptr != '\r')
        {
            pasword_iot[counter] = *ptr;
            ptr++;
            counter++;
        }
        pasword_iot[counter] = '\0';

        //cifrado
        for(int i=0; i < strlen(pasword_iot); i++) 
            pasword_iot_desif[i] = pasword_iot[i] ^ 0x55;
        pasword_iot_desif[strlen(pasword_iot)] = '\0';

        ESP_LOGI(TAG_T, "contrasena recivida: %s", pasword_iot);
        ESP_LOGI(TAG_T, "contrasena desifrada: %s", pasword_iot_desif);

        //first keep alive
        sprintf(tx_buffer, KEEP_ALIVE);
        aplicarXor(tx_buffer, tx_buffer_cifrado); 
        send(sock, tx_buffer_cifrado, strlen(tx_buffer_cifrado), 0);
        ESP_LOGI(TAG_T, "Message send to %s: %s", HOST_TCP, tx_buffer);
        setTimer();

        // Capturar comandos de la pagina 
        while(1) 
        {

            //enviar mensaje
            if(!send_f && b_state)
            {
                send_f++;
                sprintf(tx_buffer, SEND_MESSAGE);
                aplicarXor(tx_buffer, tx_buffer_cifrado); 
                send(sock, tx_buffer_cifrado, strlen(tx_buffer_cifrado), 0);
                ESP_LOGI(TAG_T, "Message send to %s: %s", HOST_TCP, tx_buffer);
            }
            else if(!b_state)
                send_f = 0;

            int len = recv(sock, rx_buffer, sizeof(rx_buffer) - 1, 0);
            if(len > 0)
            {
                rx_buffer[len] = '\0'; 
                //rx_buffer_xor
                aplicarXor(rx_buffer, rx_buffer_xor);
                strcpy(rx_buffer, rx_buffer_xor); //copiar

                ESP_LOGI(TAG_T, "Received %d bytes", len);
                ESP_LOGI(TAG_T, "%s", rx_buffer);

                if(strncmp(rx_buffer, "ACK", 3) == 0) //ACK from keep alive
                {
                    ESP_LOGI(TAG_T, "Received ACK");
                    continue;
                }
                if(strncmp(rx_buffer, "NACK", 4) == 0)
                {
                    //ESP_LOGE(TAG_T, "Conection lost, restarting...");
                    //break;
                    ESP_LOGE(TAG_T, "Received NACK");
                    continue;
                }

                ptr = rx_buffer;
                counter_cmmd = 0;
                counter_word = 0;

                //initialize commands
                for(int i=0; i<COMMANDS_QUANTITY; i++)
                    *command[i] = '\0';

                //separate by delimiter
                while(*ptr != '\0')
                {
                    if(*ptr == ':')
                    {
                        command[counter_cmmd][counter_word] = '\0'; // terminator
                        counter_cmmd++;
                        if(counter_cmmd == COMMANDS_QUANTITY)
                            continue;
                        counter_word = 0;
                    }
                    else
                    {
                        command[counter_cmmd][counter_word] = *ptr;
                        counter_word++;
                    }
                    ptr++;
                }
                command[counter_cmmd][counter_word] = '\0';

                //ESP_LOGI(TAG_T,"com: %s %s %s %s %s", command[0], command[1], command[2], command[3], command[4]);

                //check command
                if(strcmp(command[ID_T], "UABC") == 0 && strcmp(command[USER_T], USER_KEY) == 0)
                {
                    if(strcmp(command[OPERATION_T], "R") == 0) //LECTURA
                    {
                        handleRead(command, tx_buffer);
                    }
                    else if(strcmp(command[OPERATION_T], "W") == 0) //ESCRITURA
                    {
                        handleWrite(command, tx_buffer);
                    }
                    else
                        nackMessage(tx_buffer); 
                }
                else
                    nackMessage(tx_buffer);

                //vTaskDelay(pdMS_TO_TICKS(50));
                aplicarXor(tx_buffer, tx_buffer_cifrado); 
                send(sock, tx_buffer_cifrado, strlen(tx_buffer_cifrado), 0);
                ESP_LOGI(TAG_T, "Message send to %s: %s", HOST_TCP, tx_buffer);
            }
        }
    
        ESP_LOGE(TAG_T, "Shutting down socket and restarting...");
        shutdown(sock, 0);
        close(sock);
        //vTaskDelete(timer_handle);
        if (xTimerStop(timer1, 0) == pdPASS) {
            if (xTimerDelete(timer1, 0) == pdPASS)
                ESP_LOGI(TAG_T, "Timer deleted...");
            else 
                ESP_LOGE(TAG_T, "Failed to delete timer");
        } else {
            ESP_LOGE(TAG_T, "Failed to stop timer");
        }
        vTaskDelay(pdMS_TO_TICKS(5000));
    }
    ESP_LOGE(TAG_T, "TCP task closed.");
    shutdown(sock, 0);
    close(sock);
    vTaskDelete(NULL);
}

void handleRead(char command[][128], char *tx_buffer)
{
    char str[STR_LEN] = "NULL";

    if(strcmp(command[ELEMENT_T], "L") == 0)
        sprintf(tx_buffer, "ACK:%d", l_state);
    else if(strcmp(command[ELEMENT_T], "A") == 0)
        sprintf(tx_buffer, "ACK:%.2f", adc_value);
    else if(strcmp(command[ELEMENT_T], "WIFI") == 0)
    {
        read_nvs(key_ssid, str, sizeof(str));
        sprintf(tx_buffer, "ACK:%s", str);
    }
    else if(strcmp(command[ELEMENT_T], "PASS") == 0)
    {
        read_nvs((const char*)key_pass, str, sizeof(str));
        sprintf(tx_buffer, "ACK:%s", str);
    }
    else if(strcmp(command[ELEMENT_T], "P") == 0)
    {
        uint32_t value_pwm = ledc_get_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_0);
        sprintf(tx_buffer, "ACK:%" PRIu32 "", value_pwm);
    }
    else
        nackMessage(tx_buffer);
}

void handleWrite(char command[][128], char *tx_buffer)
{
    if(strcmp(command[ELEMENT_T], "L") == 0)
    {
        if(strcmp(command[VALUE_T], "1") == 0)
        {
            sprintf(tx_buffer, "ACK");
            l_state = 1;
        }
        else if(strcmp(command[VALUE_T], "0") == 0)
        {
            sprintf(tx_buffer, "ACK");
            l_state = 0;
        }
        else
            nackMessage(tx_buffer);
    }
    else if(strcmp(command[ELEMENT_T], "WIFI") == 0)
    {
        write_nvs(key_ssid, command[VALUE_T]);
        sprintf(tx_buffer, "ACK:%s", command[VALUE_T]);
    }
    else if(strcmp(command[ELEMENT_T], "PASS") == 0)
    {
        write_nvs((const char*)key_pass, command[VALUE_T]);
        sprintf(tx_buffer, "ACK:%s", command[VALUE_T]);
    }
    else if(strcmp(command[ELEMENT_T], "P") == 0)
    {
        if(strcmp(command[VALUE_T], "25") == 0)
        {
            ledc_set_duty(LEDC_HIGH_SPEED_MODE, 
                        LEDC_CHANNEL_0, 
                        (uint32_t)(MAX_DUTY_RESOLUTION * 0.25)); //25%
            ledc_update_duty(LEDC_HIGH_SPEED_MODE,LEDC_CHANNEL_0);
            sprintf(tx_buffer, "ACK:%s", command[VALUE_T]);
        }
        else if(strcmp(command[VALUE_T], "50") == 0)
        {
            ledc_set_duty(LEDC_HIGH_SPEED_MODE, 
                        LEDC_CHANNEL_0, 
                        (uint32_t)(MAX_DUTY_RESOLUTION * 0.5)); //50%
            ledc_update_duty(LEDC_HIGH_SPEED_MODE,LEDC_CHANNEL_0);
            sprintf(tx_buffer, "ACK:%s", command[VALUE_T]);
        }
        else if(strcmp(command[VALUE_T], "100") == 0)
        {
            ledc_set_duty(LEDC_HIGH_SPEED_MODE, 
                        LEDC_CHANNEL_0, 
                        (uint32_t)(MAX_DUTY_RESOLUTION)); //100%
            ledc_update_duty(LEDC_HIGH_SPEED_MODE,LEDC_CHANNEL_0);
            sprintf(tx_buffer, "ACK:%s", command[VALUE_T]);
        }
        else
        nackMessage(tx_buffer);
    }
    else
        nackMessage(tx_buffer);
}

void nackMessage(char *str)
{
    sprintf(str, "NACK");
}

void aplicarXor(char *original_message, char *mensaje_cifrado)
{
    for(int i=0; i < strlen(original_message); i++)
        mensaje_cifrado[i] = original_message[i] ^ 0x55;

    mensaje_cifrado[strlen(original_message)] = '\0';
}
#include "gpio.h"

volatile uint8_t l_state = 0, b_state = 0;

void init_gpio(void)
{
    gpio_set_direction(LED, GPIO_MODE_OUTPUT);
    gpio_set_level(LED, 0);

    gpio_set_direction(LED_PWM, GPIO_MODE_OUTPUT);
    gpio_set_level(LED_PWM, 0);

    gpio_set_direction(BUTTON, GPIO_MODE_INPUT);
    gpio_pulldown_en(BUTTON);
}


void set_led(uint8_t state)
{
    if(state)
    {
        gpio_set_level(LED, 1);
        l_state = 1;
    }
    else
    {
        gpio_set_level(LED, 0);
        l_state = 0;
    }
}

void get_button(void)
{
    b_state = gpio_get_level(BUTTON);

    /*
    if(old_b_state > new_b_state) // 1->0 TRUE
        falling_edge_f++;
    else if(old_b_state < new_b_state) // 0->1 FALSE
        falling_edge_f = 0;
    */
}

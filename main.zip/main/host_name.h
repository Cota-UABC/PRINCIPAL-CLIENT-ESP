#ifndef HOST_NAME
#define HOST_NAME

#include "nvs_esp.h"

void set_device_hostname(char *name);

void get_device_hostname(char *name);

#endif

#ifndef TCP_S
#define TCP_S

#include <stdio.h>
#include <string.h>
#include <inttypes.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/timers.h"
#include "freertos/event_groups.h"
#include "freertos/queue.h"

#include "lwip/inet.h"
#include "lwip/netdb.h"
#include "lwip/sockets.h"
#include "lwip/ip_addr.h"
#include "lwip/err.h"
#include "lwip/sys.h"

#include "nvs_flash.h"
#include "ping/ping_sock.h"

#include "freertos/timers.h"

#include "gpio.h"
#include "adc.h"
#include "nvs_esp.h"
#include "pwm.h"

#define TIMER_RESET 5000 //miliseconds

#define STR_LEN 128
#define COMMANDS_QUANTITY 6

//#define PORT_TCP 8266
#define PORT_TCP 8277 //examen
#define HOST_TCP "82.180.173.228" //iot-uabc.site

//#define PORT_TCP 5090
//#define HOST_TCP "192.168.217.93" //local server

#define USER_KEY "BCR"
#define LOGIN_KEY "UABC:BCR:L:S:login"
#define KEEP_ALIVE "UABC:BCR:K:S:alive"
#define SEND_MESSAGE "UABC:BCR:M:S:6644871544:mensaje"

//command parts
#define ID_T 0
#define USER_T 1
#define OPERATION_T 2
#define ELEMENT_T 3
#define VALUE_T 4
#define COMMENT_T 5

extern int sock;

extern TimerHandle_t timer1;
extern const int timerId;

extern char rx_buffer[STR_LEN], tx_buffer[STR_LEN], *ptr, command[COMMANDS_QUANTITY][STR_LEN];

extern uint8_t send_f;

void vTimerCallback(TimerHandle_t pxTimer);

void setTimer();

void tcp_server_task(void *pvParameters);

void keep_alive_task(void *pvParameters);

void handleRead(char command[][128], char *tx_buffer);

void handleWrite(char command[][128], char *tx_buffer);

void nackMessage(char *str);

void aplicarXor(char *original_message, char *mensaje_cifrado);

#endif

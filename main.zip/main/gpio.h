#ifndef GPIO
#define GPIO

#include "driver/gpio.h"

#define LED GPIO_NUM_2
#define LED_PWM GPIO_NUM_15
#define BUTTON GPIO_NUM_23

extern volatile uint8_t l_state, b_state;
//extern volatile uint8_t falling_edge_f, rising_edge_f; 

void init_gpio(void);

void set_led(uint8_t state);

void get_button(void);

#endif 